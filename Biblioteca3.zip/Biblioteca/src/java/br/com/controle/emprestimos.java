/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controle;

public class emprestimos {
    private int id; 
    private String aluno; 
    private int livronumero; 
    private String livronome;
    private int matricula;
    private String estatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public int getLivronumero() {
        return livronumero;
    }

    public void setLivronumero(int livronumero) {
        this.livronumero = livronumero;
    }

    public String getLivronome() {
        return livronome;
    }

    public void setLivronome(String livronome) {
        this.livronome = livronome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }
    
    
}
