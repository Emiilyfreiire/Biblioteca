package br.com.controle;

import java.util.Date;

public class Registro {
    private String aluno;
    private String livronumero;
    private String livronome;
    private Date dataEmprestimo;
    private Date dataDevolucao;

    // Getters e setters
    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getLivronumero() {
        return livronumero;
    }

    public void setLivronumero(String livronumero) {
        this.livronumero = livronumero;
    }

    public String getLivronome() {
        return livronome;
    }

    public void setLivronome(String livronome) {
        this.livronome = livronome;
    }

    public Date getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(Date dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
}
