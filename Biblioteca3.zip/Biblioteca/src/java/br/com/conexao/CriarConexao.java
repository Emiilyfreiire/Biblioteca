package br.com.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CriarConexao {
    
  
    public static Connection getConexao() throws SQLException {
        try {
         
            Class.forName("com.mysql.cj.jdbc.Driver");

           
            String url = "jdbc:mysql://localhost:3306/biblioteca?useTimezone=true&serverTimezone=UTC";

           
            return DriverManager.getConnection(url, "root", "");
            
        } catch (SQLException e) {
          
            throw new SQLException("Erro na conexão com o banco de dados: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            
            throw new SQLException("Driver JDBC não encontrado: " + e.getMessage());
        }
    }

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
