package CadastrarLivroServlet;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registrarEmprestimo")
public class CadastroLivroServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
        String Aluno = request.getParameter("estudantenome");
        String livronome = request.getParameter("nomelivro");
        String livronumero = request.getParameter("numerolivro");
        String matricula = request.getParameter("matricula");

       
        try (Connection conn = CriarConexao.getConexao()) {
         
            String sql = "INSERT INTO emprestimos (aluno, livronumero, livronome, matricula, estatus) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, Aluno);
            stmt.setString(2, livronumero);
            stmt.setString(3, livronome);
            stmt.setString(4, matricula);
            stmt.setString(5, "Não devolvido"); 

           
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                
                response.sendRedirect("listar-registros");
            } else {
               
                response.getWriter().println("Erro ao registrar o empréstimo.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Erro ao registrar o empréstimo: " + e.getMessage());
        }
    }
}

