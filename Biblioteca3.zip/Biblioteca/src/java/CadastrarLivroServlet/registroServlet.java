package CadastrarLivroServlet;

import br.com.conexao.CriarConexao;
import br.com.controle.Registro;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registrar-emprestimo")
public class registroServlet extends HttpServlet {

    // Método do GET para listar registros
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Conectando ao banco de dados
            conn = CriarConexao.getConexao();
            stmt = conn.createStatement();
            
            // Consulta à tabela 'registro' para exibir registros
            String sql = "SELECT * FROM registro";
            rs = stmt.executeQuery(sql);

            // Lista para armazenar os registros
            List<Registro> registros = new ArrayList<>();
            while (rs.next()) {
                Registro reg = new Registro();
                reg.setAluno(rs.getString("aluno"));
                reg.setLivronumero(rs.getString("livronumero"));
                reg.setLivronome(rs.getString("livronome"));
                reg.setDataEmprestimo(rs.getDate("data_emprestimo"));
                reg.setDataDevolucao(rs.getDate("data_devolucao"));
                registros.add(reg);
            }

            // Passando os registros para o JSP
            request.setAttribute("registros", registros);
            RequestDispatcher dispatcher = request.getRequestDispatcher("registro.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Método do POST para registrar empréstimos
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement stmt = null;

        // Recuperando os parâmetros do formulário
        String nomeAluno = request.getParameter("estudantenome");
        String numeroLivro = request.getParameter("livronumero");
        String nomeLivro = request.getParameter("nomelivro");
        String matricula = request.getParameter("matricula");
        String estatus = "Não devolvido"; // Estatus inicial do empréstimo

        try {
            // Conectando ao banco de dados
            conn = CriarConexao.getConexao();
            // SQL para inserir o empréstimo na tabela 'emprestimos'
            String sql = "INSERT INTO emprestimos (aluno, livronumero, livronome, matricula, estatus) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nomeAluno);
            stmt.setString(2, numeroLivro);
            stmt.setString(3, nomeLivro);
            stmt.setString(4, matricula);
            stmt.setString(5, estatus);

            int rows = stmt.executeUpdate();

            // Se inserido com sucesso, redireciona para a listagem de registros
            if (rows > 0) {
                response.sendRedirect("listar-registros");  // Redireciona para o JSP que lista os registros
            } else {
                response.getWriter().println("Erro ao registrar o empréstimo.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Erro: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
